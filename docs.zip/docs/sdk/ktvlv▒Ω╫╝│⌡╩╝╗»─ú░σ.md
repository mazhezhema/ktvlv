# ktvlv 标准初始化模板

## 🎯 适用于 F133 平台初始化流程

> **注意**：本文档仅针对 F133 平台。所有 SDL 仿真相关代码已删除。

本文档提供 ktvlv 项目的标准初始化模板，确保 UI 初始化顺序正确，避免 0xC0000005 崩溃和首帧刷新问题。

---

## 📋 完整的初始化顺序

```cpp
// ============================================================
// 1️⃣ LVGL 初始化
// ============================================================
lv_init();

// ============================================================
// 2️⃣ 显示驱动初始化（F133 framebuffer）
// ============================================================
#ifdef KTV_PLATFORM_F133_LINUX
#include "drivers/display_driver.h"

// 初始化 framebuffer 驱动
if (!DISPLAY.init()) {
    // 错误处理
    return -1;
}

lv_disp_draw_buf_t draw_buf;
lv_color_t buf1[LV_HOR_RES_MAX * 100];
lv_color_t buf2[LV_HOR_RES_MAX * 100];
lv_disp_draw_buf_init(&draw_buf, buf1, buf2, LV_HOR_RES_MAX * 100);

lv_disp_drv_t disp_drv;
lv_disp_drv_init(&disp_drv);
disp_drv.flush_cb = DISPLAY.flush;  // F133 framebuffer flush
disp_drv.draw_buf = &draw_buf;
disp_drv.hor_res = LV_HOR_RES_MAX;
disp_drv.ver_res = LV_VER_RES_MAX;
lv_disp_t* disp = lv_disp_drv_register(&disp_drv);
lv_disp_set_default(disp);
#endif

// ============================================================
// 3️⃣ 输入驱动初始化（F133 evdev）
// ============================================================
#ifdef KTV_PLATFORM_F133_LINUX
#include "drivers/input_driver.h"
#include "platform/f133_linux/input_evdev.h"

// 初始化 evdev 驱动
if (!INPUT.init()) {
    // 错误处理
    return -1;
}

// 注册触摸屏设备
INPUT.register_device(INPUT_TYPE_POINTER);

// 注册遥控器/键盘设备
INPUT.register_device(INPUT_TYPE_KEYPAD);
#endif

// ============================================================
// 4️⃣ UI 系统初始化（主题、缩放、焦点）
// ============================================================
ktv::ui::init_ui_system(LV_HOR_RES_MAX, LV_VER_RES_MAX);

// ============================================================
// 5️⃣ 服务初始化
// ============================================================
ktv::services::HttpService::getInstance().initialize(base_url, timeout);
ktv::services::LicenceService::getInstance().initialize();
ktv::services::HistoryService::getInstance().setCapacity(50);
ktv::services::M3u8DownloadService::getInstance().initialize();

// ============================================================
// 6️⃣ 创建主屏幕
// ============================================================
lv_obj_t* scr = ktv::ui::create_main_screen();
if (!scr || !lv_obj_is_valid(scr)) {
    // 错误处理
    return -1;
}

// ============================================================
// 7️⃣ 加载屏幕并设置尺寸
// ============================================================
lv_scr_load(scr);
lv_obj_set_size(scr, LV_HOR_RES_MAX, LV_VER_RES_MAX);

// 短暂延迟，让对象创建完成（但不触发刷新）
usleep(20000);  // 20ms

// ============================================================
// 8️⃣ 主循环（带首次刷新保护）
// ============================================================
bool first_refresh_done = false;
int ready_check_count = 0;

while (!quit) {
    // ✅ 首次刷新保护：确保屏幕完全ready后再刷新
    if (!first_refresh_done) {
        ready_check_count++;
        if (is_screen_ready_for_refresh(ready_check_count)) {
            first_refresh_done = true;
            fprintf(stderr, "🔥 First refresh: Screen is READY, entering normal cycle\n");
        } else {
            if (ready_check_count <= 5) {
                fprintf(stderr, "First refresh: screen not ready yet (check #%d), skipping...\n", 
                        ready_check_count);
            }
            usleep(10000);  // 10ms
            continue;
        }
    }
    
    // 正常刷新流程
    uint32_t delay = lv_timer_handler();
    uint32_t delay_ms = delay > 5 ? delay : 5;
    usleep(delay_ms * 1000);  // 转换为微秒
    
    // 处理输入事件
    // ...
}
```

---

## 🔍 READY 判定标准（三项必须全部满足）

```cpp
/**
 * @brief 检查屏幕是否ready，可以安全刷新
 * 
 * READY 判定标准：
 * 1. ✅ 屏幕对象存在且有效
 * 2. ✅ 屏幕尺寸正常（width > 0 && height > 0）
 * 3. ✅ 屏幕有至少一个子对象（KTV界面不应该为空屏）
 */
static bool is_screen_ready_for_refresh(int check_count = 0) {
    // 1. 检查屏幕是否存在
    lv_obj_t* scr = lv_scr_act();
    if (scr == NULL) {
        if (check_count < 3) {
            fprintf(stderr, "Screen ready check #%d: Screen not exist yet\n", check_count);
        }
        return false;
    }
    
    // 2. 检查屏幕对象是否有效
    if (!lv_obj_is_valid(scr)) {
        if (check_count < 3) {
            fprintf(stderr, "Screen ready check #%d: Screen object is invalid\n", check_count);
        }
        return false;
    }
    
    // 3. 检查屏幕尺寸是否正常
    lv_coord_t width = lv_obj_get_width(scr);
    lv_coord_t height = lv_obj_get_height(scr);
    if (width <= 0 || height <= 0) {
        if (check_count < 3) {
            fprintf(stderr, "Screen ready check #%d: Screen size invalid (width=%d, height=%d)\n", 
                    check_count, (int)width, (int)height);
        }
        return false;
    }
    
    // 4. 检查是否有至少一个可见子对象（KTV界面不应该为空屏）
    uint32_t child_cnt = lv_obj_get_child_cnt(scr);
    if (child_cnt == 0) {
        if (check_count < 3) {
            fprintf(stderr, "Screen ready check #%d: Screen empty (no children)\n", check_count);
        }
        return false;
    }
    
    // 全部条件满足，屏幕已READY
    if (check_count < 3) {
        fprintf(stderr, "Screen ready check #%d: ✅ All conditions met (size=%dx%d, children=%u), READY!\n", 
                check_count, (int)width, (int)height, (unsigned)child_cnt);
    }
    return true;
}
```

---

## ⚠️ 关键注意事项

### 1. 不要在初始化阶段立即刷新

❌ **错误做法：**
```cpp
lv_scr_load(scr);
lv_obj_update_layout(scr);  // ❌ 过早
lv_obj_invalidate(scr);      // ❌ 过早
lv_timer_handler();          // ❌ 过早
```

✅ **正确做法：**
```cpp
lv_scr_load(scr);
lv_obj_set_size(scr, LV_HOR_RES_MAX, LV_VER_RES_MAX);  // ✅ 安全操作
usleep(20000);  // ✅ 让对象创建完成（20ms）
// 进入主循环后再刷新
```

### 2. 首次刷新必须在主循环中进行

✅ **正确流程：**
```
创建屏幕 → 加载屏幕 → 设置尺寸 → 延迟 → 进入主循环 → 检查READY → 首次刷新
```

### 3. READY 检查的三项标准

必须同时满足：
- 屏幕对象存在且有效
- 屏幕尺寸正常（width > 0 && height > 0）
- 屏幕有至少一个子对象

---

## 🚀 F133 平台实现

```cpp
usleep(ms * 1000);  // 延迟（微秒）
evdev_read_events_exported();  // evdev 事件处理（在主循环中调用）
```

---

## 📊 初始化流程图

```
┌─────────────────┐
│   lv_init()      │
└────────┬─────────┘
         │
┌────────▼─────────┐
│  init_display()   │
└────────┬─────────┘
         │
┌────────▼─────────┐
│   init_input()   │
└────────┬─────────┘
         │
┌────────▼─────────┐
│ init_ui_system() │
└────────┬─────────┘
         │
┌────────▼─────────┐
│  init_services() │
└────────┬─────────┘
         │
┌────────▼─────────┐
│create_main_screen│
└────────┬─────────┘
         │
┌────────▼─────────┐
│  lv_scr_load()   │
└────────┬─────────┘
         │
┌────────▼─────────┐
│  set_size + delay │
└────────┬─────────┘
         │
┌────────▼─────────┐
│   主循环开始      │
└────────┬─────────┘
         │
┌────────▼─────────┐
│ 检查READY条件     │
└────────┬─────────┘
         │
    ┌────┴────┐
    │  READY? │
    └────┬────┘
         │
    ┌────▼────┐
    │ 首次刷新 │
    └────┬────┘
         │
┌────────▼─────────┐
│  正常刷新循环     │
└──────────────────┘
```

---

## ✅ 验证清单

初始化完成后，检查以下项：

- [ ] 屏幕对象创建成功
- [ ] 屏幕已加载（`lv_scr_act()` 返回有效对象）
- [ ] 屏幕尺寸已设置（width > 0 && height > 0）
- [ ] 屏幕有子对象（`lv_obj_get_child_cnt() > 0`）
- [ ] 首次刷新在主循环中进行
- [ ] 无 0xC0000005 崩溃
- [ ] UI 正常显示

---

## 📝 总结

> **ktvlv 标准初始化原则：**
> 
> 1. 严格按照顺序初始化：LVGL → 显示 → 输入 → UI系统 → 服务 → 屏幕创建
> 2. 屏幕加载后不立即刷新，延迟到主循环
> 3. 首次刷新前必须通过 READY 检查（三项标准）
> 4. 让 LVGL 自然处理布局计算和刷新

遵循此模板，可以确保 F133 平台稳定运行，避免初始化阶段的崩溃和刷新问题。

> **注意**：本文档仅针对 F133 平台。所有 SDL 仿真相关代码已删除。

---

**文档版本：** v1.0  
**最后更新：** 2025-12-30  
**适用平台：** F133 Linux（唯一支持的平台）


