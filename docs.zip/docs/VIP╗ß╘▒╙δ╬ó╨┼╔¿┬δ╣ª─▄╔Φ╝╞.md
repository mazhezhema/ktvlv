# VIP会员与微信扫码功能设计

> **文档版本**：v1.0  
> **最后更新**：2025-12-30  
> **状态**：第一期功能

## 🎯 功能概述

### 1. VIP会员功能
- **用途**: 会员状态管理、VIP歌曲标识、会员权益展示
- **功能点**:
  - 会员状态显示（是否VIP、到期时间等）
  - VIP歌曲标识（在歌曲列表中标识VIP歌曲）
  - 会员权益展示（VIP专享功能说明）
  - 扫码激活（通过微信扫码激活会员）

### 2. 微信扫码点歌功能
- **用途**: 通过微信扫码进行点歌或激活
- **功能点**:
  - 生成二维码（点歌二维码、激活二维码）
  - 扫码识别（识别微信扫码结果）
  - 扫码点歌（用户扫码后自动添加到播放列表）
  - 扫码激活（用户扫码后激活会员或设备）

---

## 🔧 技术实现方案

### 方案1: 服务器生成二维码（推荐）⭐

**优势**:
- ✅ 二维码由服务器生成，客户端只需显示
- ✅ 二维码内容可控，便于管理
- ✅ 支持动态更新二维码内容

**架构**:
```
应用层
├── 请求服务器生成二维码（HTTP GET）
├── 接收二维码图片（PNG/JPEG）
├── 在LVGL中显示二维码
└── 监听扫码结果（服务器回调或轮询）
```

### 方案2: 客户端生成二维码（可选）

**优势**:
- ✅ 不需要网络请求
- ✅ 响应速度快

**劣势**:
- ❌ 需要集成二维码生成库（如 qrcodegen）
- ❌ 二维码内容需要预先确定

---

## 📦 需要的库和依赖

### 必需库（已包含）

| 库名 | 用途 | 状态 |
|------|------|------|
| **libcurl** | 请求服务器生成二维码 | ✅ 已包含 |
| **cJSON** | 解析服务器响应 | ✅ 已包含 |
| **LVGL** | 显示二维码图片 | ✅ 已包含 |

### 可选库（根据方案选择）

#### 方案1: 服务器生成（推荐）
- ✅ **不需要额外库** - 使用现有的 libcurl + cJSON
- ✅ 服务器端生成二维码图片

#### 方案2: 客户端生成
- ⚠️ **qrcodegen** - 二维码生成库（C++，轻量级）
- ⚠️ **或 zxing-cpp** - 二维码生成库（C++，功能更全）

---

## 🔌 接口设计

### VIP会员接口

#### 1. 获取会员状态

```http
GET /api/user/vip/status?token={token}

Response:
{
    "success": true,
    "is_vip": true,
    "vip_expire_time": "2025-12-31 23:59:59",
    "vip_level": 1,
    "vip_benefits": [
        "VIP专享歌曲",
        "无广告播放",
        "高清画质"
    ]
}
```

#### 2. 检查歌曲VIP状态

```http
GET /api/song/{song_id}/vip?token={token}

Response:
{
    "success": true,
    "song_id": 12345,
    "is_vip": true,
    "is_free": false,
    "vip_level_required": 1
}
```

#### 3. 扫码激活会员

```http
POST /api/user/vip/activate
Content-Type: application/json

{
    "token": "...",
    "qr_code": "扫码结果"
}

Response:
{
    "success": true,
    "message": "激活成功",
    "vip_expire_time": "2025-12-31 23:59:59"
}
```

### 微信扫码接口

#### 1. 生成点歌二维码

```http
GET /api/qrcode/song?token={token}&song_id={song_id}

Response:
{
    "success": true,
    "qr_code_url": "https://example.com/qrcode/song_12345.png",
    "qr_code_data": "点歌数据（可选）"
}
```

#### 2. 生成激活二维码

```http
GET /api/qrcode/activate?token={token}&device_id={device_id}

Response:
{
    "success": true,
    "qr_code_url": "https://example.com/qrcode/activate_xxx.png",
    "qr_code_data": "激活数据（可选）"
}
```

#### 3. 检查扫码结果（轮询）

```http
GET /api/qrcode/status?token={token}&qr_code_id={qr_code_id}

Response:
{
    "success": true,
    "status": "scanned",  // pending, scanned, completed, expired
    "result": {
        "action": "add_song",
        "song_id": 12345,
        "song_name": "歌曲名称"
    }
}
```

---

## 🎨 UI设计

### VIP会员中心页面

```
┌─────────────────────────────────────────┐
│  VIP会员中心                              │
├─────────────────────────────────────────┤
│                                          │
│  会员状态：                              │
│  ✅ VIP会员（有效期至 2025-12-31）        │
│                                          │
│  会员权益：                              │
│  • VIP专享歌曲                           │
│  • 无广告播放                            │
│  • 高清画质                              │
│                                          │
│  [扫码激活] [续费会员]                    │
│                                          │
│  扫码激活：                              │
│  ┌─────────────┐                        │
│  │             │                        │
│  │  二维码图片  │                        │
│  │             │                        │
│  └─────────────┘                        │
│  使用微信扫码激活会员                     │
│                                          │
└─────────────────────────────────────────┘
```

### 歌曲列表VIP标识

```
┌─────────────────────────────────────────┐
│  歌曲列表                                │
├─────────────────────────────────────────┤
│  [VIP] 歌曲名称 - 歌手名称               │
│  歌曲名称 - 歌手名称                     │
│  [VIP] 歌曲名称 - 歌手名称               │
│  歌曲名称 - 歌手名称                     │
└─────────────────────────────────────────┘
```

### 微信扫码点歌页面

```
┌─────────────────────────────────────────┐
│  微信扫码点歌                             │
├─────────────────────────────────────────┤
│                                          │
│  使用微信扫码点歌：                       │
│  ┌─────────────┐                        │
│  │             │                        │
│  │  二维码图片  │                        │
│  │             │                        │
│  └─────────────┘                        │
│                                          │
│  扫码后，歌曲将自动添加到播放列表         │
│                                          │
│  [刷新二维码] [返回]                      │
│                                          │
└─────────────────────────────────────────┘
```

---

## 🔧 实现细节

### 1. VIP歌曲标识

在歌曲列表中，根据服务器返回的 `is_vip` 字段显示VIP标识：

```c
// 歌曲列表项
typedef struct {
    char song_id[64];
    char song_name[128];
    char artist[128];
    bool is_vip;        // VIP标识
    bool is_free;       // 是否免费
    int vip_level_required;  // 所需VIP等级
} SongItem;

// 显示歌曲列表项
void display_song_item(SongItem* song) {
    if (song->is_vip) {
        // 显示VIP标识
        lv_obj_t* vip_label = lv_label_create(song_item);
        lv_label_set_text(vip_label, "[VIP]");
        lv_obj_set_style_text_color(vip_label, lv_color_hex(0xFFD700), 0);
    }
    // ... 显示歌曲名称和歌手
}
```

### 2. 二维码显示

#### 方案1: 服务器生成（推荐）

```c
// 请求服务器生成二维码
void request_qrcode(const char* type, const char* data) {
    char url[256];
    snprintf(url, sizeof(url), "/api/qrcode/%s?token=%s&data=%s", 
             type, token, data);
    
    // 使用 libcurl 请求二维码图片
    CURL* curl = curl_easy_init();
    curl_easy_setopt(curl, CURLOPT_URL, url);
    curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, write_qrcode_image);
    curl_easy_perform(curl);
    curl_easy_cleanup(curl);
}

// 在LVGL中显示二维码图片
void display_qrcode(const char* image_path) {
    lv_obj_t* img = lv_img_create(parent);
    lv_img_set_src(img, image_path);
    lv_obj_align(img, LV_ALIGN_CENTER, 0, 0);
}
```

#### 方案2: 客户端生成（可选）

```c
// 使用 qrcodegen 库生成二维码
#include "qrcodegen.h"

void generate_qrcode(const char* data, uint8_t* qr_code) {
    qrcodegen_Ecc errCorLvl = qrcodegen_Ecc_LOW;
    qrcodegen_encodeText(data, qr_code, errCorLvl, 
                         qrcodegen_VERSION_MIN, 
                         qrcodegen_VERSION_MAX, 
                         qrcodegen_Mask_AUTO, true);
}

// 将二维码转换为LVGL图片
void qrcode_to_lvgl_image(uint8_t* qr_code, lv_obj_t* canvas) {
    int size = qrcodegen_getSize(qr_code);
    for (int y = 0; y < size; y++) {
        for (int x = 0; x < size; x++) {
            bool is_black = qrcodegen_getModule(qr_code, x, y);
            lv_color_t color = is_black ? LV_COLOR_BLACK : LV_COLOR_WHITE;
            lv_canvas_set_px(canvas, x, y, color);
        }
    }
}
```

### 3. 扫码结果检查（轮询）

```c
// 轮询检查扫码结果
void poll_qrcode_status(const char* qr_code_id) {
    while (true) {
        // 请求服务器检查扫码状态
        char url[256];
        snprintf(url, sizeof(url), "/api/qrcode/status?token=%s&qr_code_id=%s",
                 token, qr_code_id);
        
        // 使用 libcurl 请求状态
        // ... 解析响应
        
        if (status == "completed") {
            // 处理扫码结果
            handle_qrcode_result(result);
            break;
        }
        
        // 等待一段时间后再次检查
        sleep(2);
    }
}
```

---

## 📊 功能优先级

### Phase 1（核心功能）- 第一期
1. ✅ VIP会员状态显示
2. ✅ VIP歌曲标识
3. ✅ 扫码激活会员（服务器生成二维码）
4. ✅ 扫码点歌（服务器生成二维码）

### Phase 2（完善功能）- 未来
1. ⚠️ 客户端生成二维码（可选）
2. ⚠️ 会员权益详细展示
3. ⚠️ VIP等级系统
4. ⚠️ 会员续费功能

---

## 📝 注意事项

### VIP功能
- ✅ **服务器API** - 需要服务器端支持VIP相关API
- ✅ **状态同步** - 会员状态需要与服务器同步
- ✅ **VIP标识** - 在歌曲列表中清晰标识VIP歌曲

### 扫码功能
- ✅ **二维码生成** - 推荐使用服务器生成，客户端显示
- ✅ **扫码结果检查** - 使用轮询方式检查扫码结果
- ✅ **二维码刷新** - 支持手动刷新二维码
- ✅ **二维码过期** - 处理二维码过期情况

### 用户体验
- ✅ **清晰提示** - VIP歌曲点击时提示需要VIP
- ✅ **扫码引导** - 清晰的扫码操作指引
- ✅ **状态反馈** - 扫码后及时反馈状态

---

## 📚 相关文档

- **项目架构设计总览**: [项目架构设计总览.md](./architecture/项目架构设计总览.md)
- **MVP版本功能清单**: [MVP版本功能清单.md](./MVP版本功能清单.md)
- **HTTP REST API客户端设计**: [HTTP_REST_API客户端设计.md](./design/HTTP_REST_API客户端设计.md)
- **接口调用顺序**: [接口调用顺序.md](./guides/接口调用顺序.md)

---

## 🎯 总结

### 第一期功能范围

**包含**：
- ✅ VIP会员中心（会员状态、VIP标识、扫码激活）
- ✅ 微信扫码点歌（扫码点歌、扫码激活）

### 技术状态

- ✅ **接口已就绪** - 使用现有的 libcurl + cJSON
- ✅ **UI设计已确定** - VIP会员中心页面、扫码页面
- ⚠️ **服务器API** - 需要服务器端支持VIP和扫码相关API
- ✅ **实现方案** - 推荐服务器生成二维码，客户端显示

---

**最后更新**: 2025-12-30


